# StockSlip – Stock & Voucher Manager (Android)

**StockSlip** એ KG એકમમાં માલનો સ્ટોક, વેચાણ અને વાઉચર ટ્રેક કરવા માટેની સામાન્ય એપ છે. તેમાં કોઈ કંપનીનું નામ ફિક્સ નથી, તેથી KGમાં માલનો હિસાબ રાખતા જુદા વ્યવસાયો પણ તેનો ઉપયોગ કરી શકે.

## મુખ્ય સુવિધાઓ

- સ્ટોકની શરૂઆત અને સ્ટોક આવક/જાવક નોંધવી
- વેચાણ પાર્ટી, તારીખ, રેફરન્સ, જથ્થો, રેટ અને કુલ રકમ નોંધવી
- વેચાણ કોણે કર્યું અને વાઉચર કોણ લઈ ગયું તે નોંધવું
- તમારી સહી થઈ કે નહીં તે ટ્રેક કરવું
- વાઉચર પાછું મળ્યું કે નહીં અને પરત મળ્યાની તારીખ નોંધવી
- બાકી વાઉચર અને સહી બાકીનું ઓવરવ્યૂ
- JSON બેકઅપ Import/Export અને CSV Export
- Offline ઉપયોગ (ડેટા તે જ ફોનમાં રહે છે)

## ખાસ: પ્રથમ વખત વાપરતા પહેલાં

આ પ્રોજેક્ટ શરૂઆતમાં 404.800 KG ઓપનિંગ સ્ટોક સાથે સેટ છે, જે મૂળ રેકોર્ડના હિસાબ માટે રાખવામાં આવ્યો હતો. બીજા વ્યવસાયે ઉપયોગ કરતા પહેલાં **સ્ટોક ઉમેરો** વિભાગમાં જઈને ઓપનિંગ સ્ટોક પોતાની જરૂર મુજબ બદલો. આ આવૃત્તિમાં જથ્થાનો એકમ KG જ છે; પીસ/બોક્સ જેવા બીજા એકમો માટે હજી સેટિંગ નથી.

જૂની વેચાણ એન્ટ્રીઓ પ્રોજેક્ટમાં ઉમેરેલી નથી. નવો રેકોર્ડ રાખવા માટે જ આ એપ છે.

## GitHub પરથી Android APK બનાવવું (ફોનથી)

1. GitHubમાં નવું repository બનાવો, ઉદાહરણ તરીકે `stockslip-app`.
2. આપેલી `StockSlip_Project.zip` ફાઇલ repositoryના rootમાં upload કરીને Commit કરો.
3. `Add file` → `Create new file` પસંદ કરો.
4. File nameમાં આ લખો: `.github/workflows/build-apk.yml`
5. સાથે આપેલી `StockSlip_Build_APK_Workflow.txt` ફાઇલ ખોલો અને તેનો આખો કોડ નવી GitHub ફાઇલમાં paste કરીને Commit કરો.
6. Repositoryના **Actions** વિભાગમાં `Build StockSlip Android APK` workflow ખોલો. જરૂર પડે તો `Run workflow` દબાવો.
7. Run સફળ થાય પછી Artifactsમાં `StockSlip-Android-APK` download કરો. ZIP extract કરીને `app-debug.apk` Androidમાં install કરો.

## Androidમાં ઇન્સ્ટોલ કરવું

APK ડાઉનલોડ થયા પછી ZIP extract કરો અને `app-debug.apk` ખોલો. Android પૂછે તો આ સ્ત્રોતમાંથી install કરવાની મંજૂરી આપો.

## ડેટા અને પ્રાઇવસી

- રેકોર્ડ તે જ ફોનની એપના local storageમાં રહે છે.
- Automatic cloud sync અથવા multi-phone sharing આ આવૃત્તિમાં નથી.
- ફોન બદલતા અથવા એપ uninstall કરતા પહેલાં JSON બેકઅપ Export કરીને સુરક્ષિત રાખો.
- દરેક અલગ યુઝરે પોતાનો બેકઅપ અલગ રાખવો.

## ટેકનિકલ વિગતો

- App name: `StockSlip`
- Android application ID: `com.stockslip.app`
- Capacitor 6, Node 20 અને Java 17
- GitHub Actionsથી Debug APK build થાય છે

> `StockSlip` નામ માટે ઝડપી વેબ શોધમાં આ જ નામની સમાન stock-and-voucher Android એપ સ્પષ્ટ રીતે સામે આવી નથી, પરંતુ આ કાનૂની ટ્રેડમાર્ક અથવા Play Store નામની ઉપલબ્ધતાની ગેરંટી નથી. જાહેર રીતે પ્રકાશિત કરતા પહેલાં નામ/ટ્રેડમાર્કની અલગ તપાસ કરવી.
